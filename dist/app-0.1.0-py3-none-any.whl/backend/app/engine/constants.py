DATA_DIR = "data"  # directory containing the documents to index
CHUNK_SIZE = 1024
CHUNK_OVERLAP = 20
PGVECTOR_SCHEMA = "public"
PGVECTOR_TABLE = "llamaindex_embedding"